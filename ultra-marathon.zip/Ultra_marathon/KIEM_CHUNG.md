# Kiểm chứng phân tích

Ngày thực hiện: 14/10/2026.

- Nguồn đầy đủ đã được đọc từng khối: 7.461.195 dòng; phạm vi sửa đúng: 26.524 dòng.
- Dữ liệu phạm vi đã được kiểm tra SHA-256 với manifest khi chạy notebook.
- Thực thi toàn bộ 13 ô code theo đúng thứ tự bằng CPython 3.13.9. Bảng, phần tổng hợp và 4 biểu đồ được lưu trong notebook. Lần chạy này thực hiện bằng CPython với cơ chế hiển thị của IPython.
- 13/13 ô thành công, không có output lỗi hay cảnh báo; 4 biểu đồ đã được xem để kiểm tra nhãn, đơn vị và độ rõ.
- Script `run_analysis.py` đã chạy riêng, kết thúc với exit code 0, tạo đủ bảng/ảnh và đạt các đối chiếu cuối bài.
- Tổng theo cự ly/giới tính/mùa khớp 26.524 dòng; tổng nhóm tuổi khớp 26.289 dòng có tuổi.
- Tốc độ nguồn so với cự ly/thời gian: sai khác lớn nhất 0.000500 km/h, nhỏ hơn ngưỡng 0,02 km/h; 0 lượt cách ly.
- csv.DictReader + math.fsum độc lập khớp số dòng và mean tốc độ của cả 4 nhóm cự ly/giới tính với sai số tuyệt đối tối đa 1e-10 km/h.
- Số ID nguồn: 21.594; phiên giải/cự ly: 502. Có 255 ID mâu thuẫn, liên quan 687 lượt; phân tích trọng số theo ID dùng mẫu đã loại toàn bộ ID mâu thuẫn.
- Xác nhận notebook đúng schema nbformat và tất cả ô code có thứ tự thực thi.

Giới hạn: không xác minh danh tính với nguồn ngoài, không xác minh độ bao phủ catalogue, không kiểm định nhân quả. Dữ liệu CSV đầy đủ và notebook gốc được giữ nguyên.

Rà soát ngày 28/10/2026: chạy lại đủ 13 ô code, xuất 4 biểu đồ; 12 bảng CSV kết quả và dữ liệu đầu vào giữ nguyên SHA-256 so với trước khi biên tập. Bản HTML được xuất lại từ notebook đã chạy.
