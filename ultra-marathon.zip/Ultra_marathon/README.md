# Ultra-marathon tại Mỹ năm 2020

Phân tích mô tả các kết quả cự ly 50 km và 50 mile, phát triển từ một notebook thực hành theo tutorial.

## Đọc và chạy
- `Ultra_marathon_hoan_chinh.ipynb`: mã Python, kết quả, 4 biểu đồ và diễn giải.
- `Ultra_marathon_bao_cao.html`: bản đọc trên trình duyệt.
- Trong Jupyter, chọn Python 3 rồi chạy **Restart Kernel and Run All Cells**.
- Từ thư mục dự án, chạy `python run_analysis.py` để ghi lại bảng và biểu đồ vào `results/`.
- Thư viện cần dùng nằm trong `requirements.txt`.

## Dữ liệu
`data/um_usa_2020_50k_50mi.csv` chứa 26.524 lượt trong phạm vi, giữ nguyên 13 cột nguồn. Muốn lọc lại từ dữ liệu đầy đủ, đặt `TWO_CENTURIES_OF_UM_RACES.csv` cạnh notebook hoặc sửa `DATA_PATH`. Quy trình đọc theo khối để xử lý nguồn 7.461.195 dòng; file đầy đủ khoảng 828 MB không được chép vào thư mục dự án. Số dòng và SHA-256 được ghi trong `data/manifest.json`.

## Xử lý và phân tích
- Lấy mã quốc gia từ cặp ngoặc cuối tên giải, bổ sung 434 lượt bị cách lọc cũ bỏ sót.
- Giữ 235 lượt thiếu tuổi cho các phân tích không dùng tuổi.
- Đọc ngày đơn và khoảng ngày; dùng ngày bắt đầu để gán tháng, mùa.
- Đối chiếu tốc độ với cự ly và thời gian; sai khác lớn nhất dưới 0,0005 km/h, không có lượt phải loại vì tốc độ.
- Có 255 ID mâu thuẫn, liên quan 687 lượt. Giữ các lượt kết quả nhưng loại ID mâu thuẫn khi đặt trọng số theo người.
- So sánh tốc độ theo nhóm tuổi, cự ly, giới tính và mùa; kiểm tra trọng số theo lượt, ID và phiên giải.

## Kiểm chứng
13 ô code được thực thi theo thứ tự bằng CPython, có lưu bảng và biểu đồ. Script chạy độc lập và các phép đối chiếu nằm trong `KIEM_CHUNG.md`, `results/validation.json`. Notebook có thể đọc kết quả đã lưu mà chưa bật kernel.

## Nguồn
Dữ liệu: https://www.kaggle.com/datasets/aiaiaidavid/the-big-dataset-of-ultra-marathon-running

Bài thực hành ban đầu được làm theo tutorial; hiện chưa tìm lại được đường dẫn gốc. `notebook_goc.ipynb` được giữ để đối chiếu.

Athlete ID là định danh trong nguồn, chưa được xác minh là người duy nhất. Các khác biệt tuổi, giới tính và mùa trong bài là thống kê mô tả.
